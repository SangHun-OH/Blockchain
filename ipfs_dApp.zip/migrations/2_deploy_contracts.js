var StoreHash = artifacts.require("StoreHash");
module.exports = function(deployer) {
  deployer.deploy(StoreHash);
};
