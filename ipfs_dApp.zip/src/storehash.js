/* eslint no-eval: 0 */
import web3 from './web3';
import StoreHash from './StoreHash.json';


//console.log(address);


//console.log(abi);


export default new web3.eth.Contract(abi, address.replace(/"/g,""));
